import React from 'react';
import {formatPrice } from '../helpers';

class Pedido extends React.Component {
    renOrd = key => {
        const fish= this.props.fishes[key];
        const count= this.props.order[key];
        return (
            <li key={key}>
                {count} kilos {fish.name} {formatPrice(count * fish.price)}
            </li>
        )
    }
    
    render(){
        const oIds = Object.keys(this.props.order);
        const tot = oIds.reduce((ptot, key) => {
            const fff= this.props.fishes[key] ;
            const ccc= this.props.order[key] ;
            return ptot + (ccc * fff.price)
        },0)

        return( 
       <div className="order-wrap"> 
       <h2>Pedido</h2>
       <ul className="order"> 
           {oIds.map(this.renOrd)}
       </ul>
       Total del pedido :<strong> {formatPrice(tot)}</strong>
        </div>
        ) 
    }
}
export default Pedido;