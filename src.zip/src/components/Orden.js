import React from 'react';
import logo from '../Qlogo.png';

class Orden extends React.Component {
    render(){
       return( 
       <div className="mio"> 
       <img className="mio" src={ logo } />
       
        </div>
        ) 
    }
}
export default Orden;