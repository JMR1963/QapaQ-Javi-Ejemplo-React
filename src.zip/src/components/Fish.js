import React from 'react';
import { formatPrice } from '../helpers';

class Fish extends React.Component {
    render(){
        const {desc, image, name, price, status} = this.props.detall;
        const isAvia = status === "available"
        return(
            <li className="menu-fish">
                <img src={image} alt={name}></img>
                <h4 className="fish-name"> {name} 
                    <span className="price">{formatPrice(price)}</span>
                </h4> 
                <p> {desc} </p>
                <button disabled={!isAvia} onClick={() => this.props.addPedido(this.props.index)}>
                {isAvia ? "Add to Cart" : "Agotado"}
                </button>
            </li>
        )
    }
}
export default Fish;
// , onClick={this.props.addPedido()}