import React from 'react';
import AddFishF from './AddFishF';

class Invent extends React.Component {
    render(){
        return(
            <div className="Inventary"> 
                <h3>Inventario</h3>
                <AddFishF addFish={this.props.addFish}/> 
                <button onClick={this.props.lSF}>Cargar Pescados Ejemplo</button>
            </div>
        )
    }
}
export default Invent;