import React from 'react';
import { BrowserRouter , Route, Switch } from 'react-router-dom';
import StoreP from './StoreP';
import App from './App';
import Nosta from './Nosta';

const Router = () => (
    <BrowserRouter>
        <Switch >
            <Route exact path="/" component={StoreP} />
            <Route path="/store/:storeid" component={App} />
            <Route component={Nosta} />
        </Switch>
    </BrowserRouter>
);

export default Router;