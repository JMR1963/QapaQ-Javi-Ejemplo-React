import React from 'react';
import Header from './Header';
import Fish from './Fish';
import Pedido from './Pedido';
import Invent from './Invent';
import sf from '../sample-fishes';

class App extends React.Component {
    state = {
        fishes: {},
        order: {}
    }
    addFish = fish => {
        //1. hacemos una copia de fishes
        const fishesx = {...this.state.fishes};
        //2. agregamos el pez
        fishesx[`fish${Date.now()}`]=fish;
        //3. seteo el fish
        this.setState({fishes: fishesx});
    
        console.log("vamooo pescado !");
    };
    lSF = () => {
        this.setState({fishes: sf});
    };
    addPedido = (key) => {
        //1. copiar el state
        const xx = {...this.state.order};
        //2. actualizar la orden o cambiar la cantidad
        xx[key] = xx[key] + 1 || 1;
        //3. llamar a setStat.e para actualizar los pedidos.
        this.setState({order : xx})
    }
    render() {
        return(
            <div className='catch-of-the-day'>
                <Invent addFish={this.addFish} lSF={this.lSF}/>
                <div className='menu'>
                <Header sublema="Los Mejores Frutos del Mar"/>
                    <ul className="fishes">
                        {Object.keys(this.state.fishes).map(key => 
                        <Fish key={key}
                        index={key} 
                        detall={this.state.fishes[key]} 
                        addPedido={this.addPedido}/>)}
                    </ul>
                {/*  <Fish /> */}
                </div> 
                <Pedido fishes={this.state.fishes} order={this.state.order}/>               
            </div>   
        );
    }
}
export default App;