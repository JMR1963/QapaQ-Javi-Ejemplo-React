import React from 'react';

const Header = (ppp) => (
    <header className="top">
        <h1>
        QapaQ 
        <span className="ofThe">
            <span className="of">te </span>
            <span className="The">da </span>
        </span>
        Todo
        </h1>  
        <h3 className="tagline">
        <span>{ppp.sublema}</span>
        </h3>   
    </header>
);

export default Header;