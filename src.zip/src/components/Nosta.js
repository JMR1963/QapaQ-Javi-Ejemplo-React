import React from 'react';

const Nosta = () => (
    <div> 
        <h2>Tienda Inexsitete </h2>  
    </div>
);
export default Nosta;