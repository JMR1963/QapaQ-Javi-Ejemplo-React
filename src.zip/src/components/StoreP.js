import React from 'react';
//import { getFunName } from '../helpers';

class StoreP extends React.Component {
    
    mInput = React.createRef();
    
    fk = event => {
        //1. parar el submit del form
        event.preventDefault();
        //2. tomar el texto del imput
        const vvv = this.mInput.current.value;
        //3. cambiar de pagina a la pag deseada
        this.props.history.push("/store/"+vvv);
    }
    render() {
        return ( 
        <React.Fragment>
        <form className="store-selector" onSubmit={this.fk}>
            <h2>Ingrese a una Tienda</h2>
            {/* commenterio */}
            <input type="text" ref={this.mInput} required placeholder="Nombre de la Tienda"/>
            <button type="submit">Visite la Tienda -></button>
        </form>
        </React.Fragment>
        ) 
    }
}
export default StoreP;
//