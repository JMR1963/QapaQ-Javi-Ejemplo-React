import React from 'react';

class AddFishF extends React.Component {
    nref = React.createRef();
    pref = React.createRef();
    sref = React.createRef();
    dref = React.createRef();
    iref = React.createRef();

    Cf = e => {
      //1. Stop forms submit
      e.preventDefault();
      const fish ={
          name: this.nref.current.value,
          price: parseFloat(this.pref.current.value),
          status: this.sref.current.value,
          desc: this.dref.current.value,
          image: this.iref.current.value,
      }
      //2. lo paso a prpiedades
      this.props.addFish(fish);
      console.log(fish);
      //2. reseteo el form
      e.currentTarget.reset();
    }
    render() {
        return (
        <form className="fish-edit" onSubmit={this.Cf}>
            <input name="name" ref={this.nref} type="text" placeholder="nombre"/>
            <input name="price" ref={this.pref} type="text" placeholder="precio"/>
            <select name="status" ref={this.sref} >
                <option value="available">Fresco !</option>
                <option value="unavailable">Vendido !</option>
            </select> 
            <textarea name="desc" ref={this.dref}  placeholder="descr"/>
            <input name="image" ref={this.iref} type="text" placeholder="imagen"/>
            <button type="submit">+ Agregar</button>
        </form>  
        )
    }
}
export default AddFishF;