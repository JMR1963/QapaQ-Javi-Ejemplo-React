// let's go!
import React from 'react';
import { render } from 'react-dom';
import Router from './components/Router';
import "./css/style.css";
import Orden from './components/Orden';

render( <Orden /> , document.querySelector('#head'));
render( <Router /> , document.querySelector('#main'));